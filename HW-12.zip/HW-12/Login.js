import React, { useState } from 'react'
import Card from '../UI/Card/Card'
import classes from './Login.module.css'
import Button from '../UI/Button/Button'
import { useEffect } from 'react'

//debouncing

const Login = (props) => {
  const [enteredEmail, setEnteredEmail] = useState('')     //email жазуу учун берилген состояние ал Input value дегенге жазылат 
  const [emailIsValid, setEmailIsValid] = useState()        //check is email valid or not
  const [enteredPassword, setEnteredPassword] = useState('') //write password
  const [passwordIsValid, setPasswordIsValid] = useState() //check password
  const [formIsValid, setFormIsValid] = useState(false) //email and password are valid

  useEffect(() => {                                                          //ушул жерден баштап 
    const timer = setTimeout(() => {     //чтобы каждый символ жазган сайын текшербеш учун таймер коюп коебуз чтобы биз жазып буткондон кийин примерный убакытта текшерсин деп                                    
      setFormIsValid(
        enteredEmail.includes('@') && enteredPassword.trim().length > 6,   //двойная проверка каждый раз когда меняется состояние 
      )
    }, 500);
    //clean up function 
  return()=>{
    clearTimeout(timer)
  }                                             //ушул жерге чейинки функция 

  },[enteredEmail,enteredPassword])           //ушул жерге жазылган нерсеге карай иштейт, 
                                             //тоесть каждый раз когда тут менятся что-то даже если false функция срабатывает 

  

  const emailChangeHandler = (event) => {     //бул дагы значениени алуу учун жана состояниеге бериш учун
    setEnteredEmail(event.target.value)
  }

  const passwordChangeHandler = (event) => {  //бул значениени алуу учун жана состояниеге бериш учун
    setEnteredPassword(event.target.value)

    // setFormIsValid(
    //   event.target.value.trim().length > 6 && enteredEmail.includes('@'),
    // )
  }

  const validateEmailHandler = () => {                       //функция которая записывается в onBlur
    setEmailIsValid(enteredEmail.includes('@'))             //объязательно собачка болуш крк если нет или башка жакты басып койсо 
                                                      //сработает onBlur и кызыл болуп калат 
  }

  const validatePasswordHandler = () => {                   //функция которая записывается в onBlur
    setPasswordIsValid(enteredPassword.trim().length > 6)  //Пароль должен состоять из более 6 символов 
  }

  const submitHandler = (event) => {                //сабмиттин функциясы 
    event.preventDefault()                         //каждый раз обновление болбосун деп 
    props.onLogin(enteredEmail, enteredPassword)  //пропстон функция келет и аргументке ушулар берилип сабмитте ушул функция журот
  }

  return (
    <Card className={classes.login}>
      <form onSubmit={submitHandler}> 
        <div
          className={`${classes.control} ${
            emailIsValid === false ? classes.invalid : ''  //эгерде emailIsValid текшеруудон отпой тоесть @жок болсо invalid класс кошулат 
          }`}
        >
          <label htmlFor="email">E-Mail</label>
          <input
            type="email"
            id="email"
            value={enteredEmail}
            onChange={emailChangeHandler}
            onBlur={validateEmailHandler}  //это фокусту текшерип турат и ошого жараша цвет озгортот 
          />
        </div>
        <div
          className={`${classes.control} ${
            passwordIsValid === false ? classes.invalid : ''  //эгерде passwordIsValid текшеруудон отпой тоесть lenght<6 болсо invalid класс кошулат 
          }`}
        >
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={enteredPassword}
            onChange={passwordChangeHandler}
            onBlur={validatePasswordHandler}
          />
        </div>
        <div className={classes.actions}>
          <Button type="submit" className={classes.btn} disabled={!formIsValid}> //кнопка будет неработать до тех пор пока требования не будут выполнены
            Login
          </Button>
        </div>
      </form>
    </Card>
  )
}

export default Login
