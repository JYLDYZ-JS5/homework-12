import React, { useState, useEffect } from 'react' //импортируем useEffect
import Login from './components/Login/Login'
import Home from './components/Home/Home'
import MainHeader from './components/MainHeader/MainHeader'

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    const stored = localStorage.getItem('isLoggedIn')  //side effect учун useeffect иштетебиз 
    if (stored === '1') {
      setIsLoggedIn(true)   //если строго равно болсо состояние c false на true 
    }
  }, [])

  const loginHandler = async (email, password) => { //функция которая вызывалась в сабмите 
    
    localStorage.setItem('isLoggedIn', '1')  //просто текшериш учун киргизилип жатат 
    setIsLoggedIn(true)                        //состояние true 
  }

  const logoutHandler = () => {  //для кнопки LogOut убрать с хранилища isLoggedIn и изменить состояние на false
    localStorage.removeItem('isLoggedIn')
    setIsLoggedIn(false)
  }

  return (
    <React.Fragment>   //фрагмент как div 
      <MainHeader isAuthenticated={isLoggedIn} onLogout={logoutHandler} />
      <main>
        {!isLoggedIn && <Login onLogin={loginHandler} />}  //если нет то рендерит form 
        {isLoggedIn && <Home onLogout={logoutHandler} />} //покажет что уже зарегистрирован 
      </main>
    </React.Fragment>
  )
}

export default App
